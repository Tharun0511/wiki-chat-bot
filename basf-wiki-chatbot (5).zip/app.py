import os
import json
import logging
import threading
import re
from collections import deque
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

_openai_client     = None
_search_client     = None
_ingest_running    = False
_ingest_logs       = deque(maxlen=500)
_last_ingest_error = None

CHAT_DEPLOYMENT      = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT",      "gpt-4o")
EMBEDDING_DEPLOYMENT = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
SEARCH_INDEX         = os.getenv("AZURE_SEARCH_INDEX",                "basf-wiki-index")
INGEST_SECRET        = os.getenv("INGEST_SECRET",                     "")

SYSTEM_PROMPT = """You are BASF Wiki Assistant, an intelligent AI chatbot for BASF employees.
You answer questions strictly based on the provided BASF ADO Wiki content.
- Always be professional, concise, and accurate.
- Use proper Markdown formatting: headers (##), bullet points (-), bold (**text**), code blocks.
- If the answer is not in the wiki, say: "I could not find this information in the BASF Wiki. Please check with your team."
- Always attribute answers to the relevant wiki page when possible.
- When describing architecture or processes, use structured formatting with clear sections.
- When the wiki context includes hyperlinks (IAC pipeline links, form links, portal links, contacts, etc.),
  include them as clickable markdown links in your response: [Descriptive Text](url).
- If the same application or service appears in results from BOTH an Azure Wiki AND an AWS Wiki source,
  present a **cross-platform comparison** with clearly labelled sections: **## Azure** and **## AWS**.
- When answering about application contacts or support teams, list all relevant names, roles, and
  any linked forms, ticketing portals, or Confluence/SharePoint pages found in the wiki context.
"""

# ── Log capture ───────────────────────────────────────────────
class MemoryLogHandler(logging.Handler):
    def emit(self, record):
        _ingest_logs.append(self.format(record))

mem_handler = MemoryLogHandler()
mem_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
logging.getLogger().addHandler(mem_handler)

# ── Client helpers ─────────────────────────────────────────────

def _make_httpx_client():
    import httpx
    return httpx.Client(timeout=httpx.Timeout(60.0), trust_env=False, verify=True)

def get_openai_client():
    global _openai_client
    if _openai_client is None:
        from openai import AzureOpenAI
        _openai_client = AzureOpenAI(
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"].rstrip("/"),
            api_key=os.environ["AZURE_OPENAI_KEY"],
            api_version="2024-05-01-preview",
            http_client=_make_httpx_client(),
        )
    return _openai_client

def get_search_client():
    global _search_client
    if _search_client is None:
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential
        _search_client = SearchClient(
            endpoint=os.environ["AZURE_SEARCH_ENDPOINT"].rstrip("/"),
            index_name=SEARCH_INDEX,
            credential=AzureKeyCredential(os.environ["AZURE_SEARCH_KEY"]),
        )
    return _search_client

def get_embedding(text: str) -> list:
    return get_openai_client().embeddings.create(
        model=EMBEDDING_DEPLOYMENT, input=text.strip()
    ).data[0].embedding

# ── Enhanced search ────────────────────────────────────────────

def expand_query(query: str) -> str:
    """
    Expand the user query with synonyms/variants to improve recall.
    Strips question words and expands acronyms common in BASF/cloud context.
    """
    expansions = {
        r"\bADO\b":      "Azure DevOps ADO",
        r"\bAP\b":       "AP Asia Pacific",
        r"\bCI/CD\b":    "CI CD pipeline continuous integration deployment",
        r"\bIaC\b":      "Infrastructure as Code IaC Terraform Bicep",
        r"\bonboard\b":  "onboard onboarding setup new project",
        r"\barch\b":     "architecture design",
        r"\bpipeline\b": "pipeline CI CD build deploy release",
        r"\bcontact\b":  "contact team member engineer role",
        r"\brelease\b":  "release deployment rollout process",
    }
    expanded = query
    for pattern, replacement in expansions.items():
        expanded = re.sub(pattern, replacement, expanded, flags=re.IGNORECASE)
    return expanded

def search_wiki(query: str, top_k: int = 8) -> list:
    """
    Enhanced hybrid search:
    - Vector search (semantic similarity)
    - Full-text keyword search (BM25)
    - Results merged and de-duplicated by wikiPath
    - Returns top unique pages ranked by combined relevance
    - Now includes extracted hyperlinks and wiki source per page
    """
    try:
        from azure.search.documents.models import VectorizedQuery

        client         = get_search_client()
        expanded_query = expand_query(query)

        # ── Vector search ──────────────────────────────────────
        query_vector = get_embedding(expanded_query)
        vector_query = VectorizedQuery(
            vector=query_vector,
            k_nearest_neighbors=top_k,
            fields="contentVector",
        )

        # ── Hybrid search: keyword + vector together ───────────
        results = client.search(
            search_text=expanded_query,
            vector_queries=[vector_query],
            select=["title", "content", "wikiPath", "pageUrl", "chunkIndex",
                    "hyperlinks", "wikiSource"],
            top=top_k * 2,
            query_type="simple",
        )

        # ── De-duplicate: keep best chunk per wiki page ────────
        seen_paths = {}
        for r in results:
            path = r.get("wikiPath", "")
            # Parse hyperlinks JSON safely
            raw_links = r.get("hyperlinks", "[]") or "[]"
            try:
                links = json.loads(raw_links)
                if not isinstance(links, list):
                    links = []
            except Exception:
                links = []

            if path not in seen_paths:
                seen_paths[path] = {
                    "title":      r.get("title", ""),
                    "content":    r.get("content", ""),
                    "wikiPath":   path,
                    "pageUrl":    r.get("pageUrl", ""),
                    "hyperlinks": links,
                    "wikiSource": r.get("wikiSource", "Azure Wiki"),
                }
            else:
                # Merge content from multiple chunks of the same page
                existing = seen_paths[path]["content"]
                new_chunk = r.get("content", "")
                if len(existing) < 1200:
                    seen_paths[path]["content"] = existing + "\n\n" + new_chunk
                # Merge any additional links from later chunks (same page shares links)
                if not seen_paths[path]["hyperlinks"] and links:
                    seen_paths[path]["hyperlinks"] = links

        docs = list(seen_paths.values())[:top_k]
        logger.info(f"Search '{query[:60]}' → {len(docs)} unique pages")
        return docs

    except Exception as e:
        logger.warning(f"Search failed: {type(e).__name__}: {e}")
        return []

def is_app_contact_query(query: str) -> bool:
    """
    Detect whether a user query is looking for application contacts, team info,
    or a cross-platform (Azure vs AWS) comparison.
    Used to enrich the GPT context with a cross-wiki comparison instruction.
    """
    patterns = [
        r'\bcontact[s]?\b',
        r'\bwho\s+(is|are|manages|owns|supports|maintains)\b',
        r'\bteam\b',
        r'\bowner\b',
        r'\bsupport\s+(team|contact|email|channel)\b',
        r'\bresponsib\w+\s+for\b',
        r'\bapplication\s+(contact|team|owner|support)\b',
        r'\b(app|service|system)\s+(contact|team|owner)\b',
        r'\bpoc\b',               # point of contact
        r'\bpoint\s+of\s+contact\b',
        r'\bescalation\b',
        r'\bAzure\s+vs\s+AWS\b',
        r'\bAWS\s+vs\s+Azure\b',
        r'\bcross[\s-]platform\b',
        r'\bcompare\b',
    ]
    q_lower = query.lower()
    return any(re.search(p, q_lower) for p in patterns)


def build_context(docs: list) -> str:
    """
    Build the context string passed to the GPT model.
    Each source section includes:
      - Source header (title, wiki path, wiki source)
      - Page content
      - Page hyperlinks (so GPT can embed them as clickable links in the answer)
    """
    if not docs:
        return ""
    parts = []
    for i, d in enumerate(docs, 1):
        header = (
            f"[Source {i}: **{d['title']}** | "
            f"Wiki Path: {d['wikiPath']} | "
            f"Source: {d.get('wikiSource', 'Wiki')}]"
        )
        body = d["content"]
        links = d.get("hyperlinks", [])
        if links:
            link_lines = "\n".join(
                f"  - [{lnk.get('text', lnk['url'])}]({lnk['url']})"
                for lnk in links[:12]
            )
            body += f"\n\nPage Hyperlinks (include relevant ones in your response):\n{link_lines}"
        parts.append(f"{header}\n{body}")
    return "\n\n---\n\n".join(parts)

# ── Routes ─────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data     = request.get_json()
        user_msg = data.get("message", "").strip()
        history  = data.get("history", [])
        images   = data.get("images", [])

        if not user_msg and not images:
            return jsonify({"error": "Empty message"}), 400

        docs    = search_wiki(user_msg) if user_msg else []
        context = build_context(docs)

        # ── Collect unique hyperlinks + wiki sources from all retrieved docs ──
        all_links         = []
        seen_link_urls    = set()
        wiki_sources_found = set()

        for doc in docs:
            src = doc.get("wikiSource", "")
            if src:
                wiki_sources_found.add(src)
            for lnk in doc.get("hyperlinks", []):
                url = lnk.get("url", "")
                if url and url not in seen_link_urls:
                    all_links.append(lnk)
                    seen_link_urls.add(url)

        # ── Cross-wiki instruction injection ──────────────────────────────────
        cross_wiki = len(wiki_sources_found) > 1
        extra_instruction = ""
        if cross_wiki and is_app_contact_query(user_msg):
            sources_str = " and ".join(sorted(wiki_sources_found))
            extra_instruction = (
                f"\n\n⚠️ IMPORTANT: Results found in MULTIPLE wiki sources: {sources_str}. "
                "Present a detailed cross-platform comparison. "
                "Use clearly labelled ## sections for each wiki source."
            )

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        for turn in history[-6:]:
            messages.append({"role": turn["role"], "content": turn["content"]})

        if images:
            content_parts = []
            if context:
                content_parts.append({"type": "text",
                                       "text": f"Wiki Context:\n{context}\n\n"})
            if user_msg:
                content_parts.append({"type": "text", "text": user_msg})
            for img_data_url in images[:4]:
                if "," in img_data_url:
                    header, b64data = img_data_url.split(",", 1)
                    mime = header.split(":")[1].split(";")[0] if ":" in header else "image/png"
                else:
                    b64data, mime = img_data_url, "image/png"
                content_parts.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime};base64,{b64data}", "detail": "high"},
                })
            messages.append({"role": "user", "content": content_parts})
        else:
            if not context:
                augmented = (
                    f"User Question: {user_msg}\n\n"
                    "Note: No relevant wiki content found. "
                    "Politely inform the user and suggest rephrasing."
                )
            else:
                augmented = (
                    f"Wiki Context:\n{context}\n\n"
                    f"User Question: {user_msg}\n\n"
                    f"Answer based on the wiki content above with Markdown formatting."
                    f"{extra_instruction}"
                )
            messages.append({"role": "user", "content": augmented})

        response = get_openai_client().chat.completions.create(
            model=CHAT_DEPLOYMENT,
            messages=messages,
            temperature=0.2,
            max_tokens=2000,
        )
        answer = response.choices[0].message.content

        sources = [
            {
                "title":      d["title"],
                "url":        d["pageUrl"],
                "wikiSource": d.get("wikiSource", ""),
            }
            for d in docs if d["title"]
        ]

        return jsonify({
            "answer":        answer,
            "sources":       sources,
            "related_links": all_links[:15],
            "wiki_sources":  sorted(wiki_sources_found),
        })

    except Exception as e:
        logger.error(f"Chat error: {type(e).__name__}: {e}", exc_info=True)
        return jsonify({"error": f"{type(e).__name__}: {str(e)}"}), 500

# ── Ingest routes ──────────────────────────────────────────────

@app.route("/trigger-ingest", methods=["POST"])
def trigger_ingest():
    global _ingest_running, _last_ingest_error
    if not INGEST_SECRET:
        return jsonify({"error": "INGEST_SECRET not configured"}), 500
    if request.headers.get("X-Ingest-Secret", "") != INGEST_SECRET:
        return jsonify({"error": "Unauthorized"}), 401
    if _ingest_running:
        return jsonify({"status": "already_running"}), 409
    required = ["AZURE_OPENAI_ENDPOINT","AZURE_OPENAI_KEY",
                "AZURE_SEARCH_ENDPOINT","AZURE_SEARCH_KEY",
                "ADO_ORG_URL","ADO_PROJECT","ADO_WIKI_ID","ADO_PAT"]
    missing = [v for v in required if not os.getenv(v)]
    if missing:
        return jsonify({"error": f"Missing env vars: {missing}"}), 500

    def run():
        global _ingest_running, _last_ingest_error
        _ingest_running = True
        _last_ingest_error = None
        _ingest_logs.clear()
        try:
            import importlib, ingest as m
            importlib.reload(m)
            m.ingest()
            logger.info("✅ Ingestion completed")
        except Exception as e:
            _last_ingest_error = f"{type(e).__name__}: {e}"
            logger.error(f"❌ Ingestion FAILED: {_last_ingest_error}", exc_info=True)
        finally:
            _ingest_running = False

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"status": "started", "message": "Ingestion started."})

@app.route("/ingest-status")
def ingest_status():
    return jsonify({"ingest_running": _ingest_running, "last_error": _last_ingest_error})

@app.route("/ingest-logs")
def ingest_logs():
    return "\n".join(_ingest_logs) or "No logs yet.", 200, {"Content-Type": "text/plain"}

@app.route("/health")
def health():
    missing = [v for v in ["AZURE_OPENAI_ENDPOINT","AZURE_OPENAI_KEY",
                            "AZURE_SEARCH_ENDPOINT","AZURE_SEARCH_KEY"] if not os.getenv(v)]
    if missing:
        return jsonify({"status": "unhealthy", "missing_vars": missing}), 500
    return jsonify({"status": "healthy", "app": "BASF Wiki Chatbot"})

@app.route("/debug")
def debug():
    doc_count, index_status, openai_status = 0, "unknown", "unknown"
    try:
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential
        sc = SearchClient(
            endpoint=os.environ["AZURE_SEARCH_ENDPOINT"].rstrip("/"),
            index_name=SEARCH_INDEX,
            credential=AzureKeyCredential(os.environ["AZURE_SEARCH_KEY"]),
        )
        r = sc.search(search_text="*", top=1, include_total_count=True)
        doc_count    = r.get_count() or 0
        index_status = f"✅ Connected — {doc_count} documents"
    except Exception as e:
        index_status = f"❌ {e}"
    try:
        get_openai_client().embeddings.create(model=EMBEDDING_DEPLOYMENT, input="test")
        openai_status = "✅ Connected"
    except Exception as e:
        openai_status = f"❌ {type(e).__name__}: {e}"
    return jsonify({
        "azure_openai_status": openai_status,
        "azure_search_status": index_status,
        "documents_in_index":  doc_count,
        "ingest_running":      _ingest_running,
        "last_ingest_error":   _last_ingest_error,
        "ado_variables": {
            "ADO_ORG_URL":  os.getenv("ADO_ORG_URL",  "❌ NOT SET"),
            "ADO_PROJECT":  os.getenv("ADO_PROJECT",  "❌ NOT SET"),
            "ADO_WIKI_ID":  os.getenv("ADO_WIKI_ID",  "❌ NOT SET"),
            "ADO_PAT":      "✅ SET" if os.getenv("ADO_PAT") else "❌ NOT SET",
        },
        "environment_variables": {
            "AZURE_OPENAI_ENDPOINT":  os.getenv("AZURE_OPENAI_ENDPOINT", "❌"),
            "AZURE_OPENAI_KEY":       "✅ SET" if os.getenv("AZURE_OPENAI_KEY")  else "❌",
            "AZURE_SEARCH_ENDPOINT":  os.getenv("AZURE_SEARCH_ENDPOINT", "❌"),
            "AZURE_SEARCH_KEY":       "✅ SET" if os.getenv("AZURE_SEARCH_KEY")  else "❌",
            "INGEST_SECRET":          "✅ SET" if os.getenv("INGEST_SECRET")     else "❌",
        },
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)