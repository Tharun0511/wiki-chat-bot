"""
BASF ADO Wiki Ingestion Script — with batching, rate limiting, retry logic,
hyperlink extraction, and multi-wiki (Azure + AWS) support.
"""

import os
import re
import json
import time
import base64
import logging
import requests
import urllib.parse
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SimpleField, SearchableField,
    SearchFieldDataType, SearchField, VectorSearch,
    HnswAlgorithmConfiguration, VectorSearchProfile,
)
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError
from openai import AzureOpenAI, RateLimitError, APIConnectionError, APITimeoutError
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────
AZURE_SEARCH_ENDPOINT = os.environ["AZURE_SEARCH_ENDPOINT"].rstrip("/")
AZURE_SEARCH_KEY      = os.environ["AZURE_SEARCH_KEY"]
AZURE_SEARCH_INDEX    = os.getenv("AZURE_SEARCH_INDEX", "basf-wiki-index")

AZURE_OPENAI_ENDPOINT = os.environ["AZURE_OPENAI_ENDPOINT"].rstrip("/")
AZURE_OPENAI_KEY      = os.environ["AZURE_OPENAI_KEY"]
EMBEDDING_DEPLOYMENT  = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")

ADO_ORG_URL  = os.environ["ADO_ORG_URL"].rstrip("/")
ADO_PROJECT  = os.environ["ADO_PROJECT"].strip("/")
ADO_WIKI_ID  = os.environ["ADO_WIKI_ID"].strip()
ADO_PAT      = os.environ["ADO_PAT"].strip()

CHUNK_SIZE            = 1500
CHUNK_OVERLAP         = 200
EMBED_BATCH_SIZE      = 16
SEARCH_BATCH_SIZE     = 50
DELAY_BETWEEN_PAGES   = 0.3
DELAY_BETWEEN_BATCHES = 1.0

logger.info(f"ADO_ORG_URL : {ADO_ORG_URL}")
logger.info(f"ADO_PROJECT : {ADO_PROJECT}")
logger.info(f"ADO_WIKI_ID : {ADO_WIKI_ID}")

# ── Clients ───────────────────────────────────────────────────
openai_client = AzureOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_KEY,
    api_version="2024-05-01-preview",
)
credential    = AzureKeyCredential(AZURE_SEARCH_KEY)
index_client  = SearchIndexClient(endpoint=AZURE_SEARCH_ENDPOINT, credential=credential)
search_client = SearchClient(
    endpoint=AZURE_SEARCH_ENDPOINT,
    index_name=AZURE_SEARCH_INDEX,
    credential=credential,
)

# ── Helpers ───────────────────────────────────────────────────

def _ado_headers(pat: str) -> dict:
    """Build ADO Basic-auth headers for the given PAT."""
    token = base64.b64encode(f":{pat}".encode()).decode()
    return {"Authorization": f"Basic {token}", "Content-Type": "application/json"}

def ado_headers() -> dict:
    """Backward-compatible helper using the primary ADO_PAT."""
    return _ado_headers(ADO_PAT)

def build_index_definition() -> SearchIndex:
    return SearchIndex(
        name=AZURE_SEARCH_INDEX,
        fields=[
            SimpleField(name="id",         type=SearchFieldDataType.String, key=True),
            SearchableField(name="title",   type=SearchFieldDataType.String),
            SearchableField(name="content", type=SearchFieldDataType.String),
            SimpleField(name="wikiPath",    type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="pageUrl",     type=SearchFieldDataType.String),
            SimpleField(name="chunkIndex",  type=SearchFieldDataType.Int32),
            # ── New fields ──────────────────────────────────────────────────
            # JSON string: [{"text": "...", "url": "..."}, ...]
            SimpleField(name="hyperlinks",  type=SearchFieldDataType.String),
            # Wiki source label, e.g. "Azure Wiki" or "AWS Wiki"
            SimpleField(name="wikiSource",  type=SearchFieldDataType.String, filterable=True),
            # ────────────────────────────────────────────────────────────────
            SearchField(
                name="contentVector",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=1536,
                vector_search_profile_name="basf-vector-profile",
            ),
        ],
        vector_search=VectorSearch(
            algorithms=[HnswAlgorithmConfiguration(name="basf-hnsw")],
            profiles=[VectorSearchProfile(
                name="basf-vector-profile",
                algorithm_configuration_name="basf-hnsw",
            )],
        ),
    )

def create_search_index():
    logger.info(f"Creating/updating index: {AZURE_SEARCH_INDEX}")
    try:
        index_client.create_or_update_index(build_index_definition())
        logger.info("Index ready ✓")
    except HttpResponseError as e:
        if "CannotChangeExistingField" in str(e) or "OperationNotAllowed" in str(e):
            logger.warning("Index schema conflict — deleting and recreating...")
            index_client.delete_index(AZURE_SEARCH_INDEX)
            logger.info(f"Index '{AZURE_SEARCH_INDEX}' deleted ✓")
            time.sleep(3)
            index_client.create_or_update_index(build_index_definition())
            logger.info("Index recreated ✓")
        else:
            raise

def get_wiki_pages(cfg: dict = None) -> list:
    """Fetch all pages from a wiki. cfg overrides the module-level ADO env vars."""
    org     = (cfg or {}).get("org_url",  ADO_ORG_URL)
    project = (cfg or {}).get("project",  ADO_PROJECT)
    wiki_id = (cfg or {}).get("wiki_id",  ADO_WIKI_ID)
    pat     = (cfg or {}).get("pat",      ADO_PAT)
    headers = _ado_headers(pat)
    url = (f"{org}/{project}/_apis/wiki/wikis/"
           f"{wiki_id}/pages?recursionLevel=full&api-version=7.1")
    logger.info(f"Fetching wiki pages: {url}")
    resp = requests.get(url, headers=headers, timeout=30)
    if resp.status_code == 401:
        raise RuntimeError(f"ADO 401 Unauthorized. Check PAT. URL: {url}")
    resp.raise_for_status()
    root, pages = resp.json(), []
    def walk(node):
        pages.append(node)
        for child in node.get("subPages", []):
            walk(child)
    walk(root)
    logger.info(f"Found {len(pages)} wiki pages ✓")
    return pages

def get_page_content(path: str, cfg: dict = None) -> str:
    """Fetch raw markdown content of a wiki page. cfg overrides module-level env vars."""
    org     = (cfg or {}).get("org_url",  ADO_ORG_URL)
    project = (cfg or {}).get("project",  ADO_PROJECT)
    wiki_id = (cfg or {}).get("wiki_id",  ADO_WIKI_ID)
    pat     = (cfg or {}).get("pat",      ADO_PAT)
    headers = _ado_headers(pat)
    encoded = urllib.parse.quote(path, safe="")
    url = (f"{org}/{project}/_apis/wiki/wikis/"
           f"{wiki_id}/pages?path={encoded}&includeContent=true&api-version=7.1")
    resp = requests.get(url, headers=headers, timeout=30)
    if resp.status_code != 200:
        logger.warning(f"  Skipping {path}: HTTP {resp.status_code}")
        return ""
    return resp.json().get("content", "")

def build_page_url(path: str, cfg: dict = None) -> str:
    """Build the ADO wiki browsable URL for a page. cfg overrides module-level env vars."""
    org     = (cfg or {}).get("org_url",  ADO_ORG_URL)
    project = (cfg or {}).get("project",  ADO_PROJECT)
    wiki_id = (cfg or {}).get("wiki_id",  ADO_WIKI_ID)
    encoded_path = urllib.parse.quote(path, safe="/")
    return (f"{org}/{project}/_wiki/wikis/"
            f"{wiki_id}?pagePath={encoded_path}")

def clean_markdown(text: str) -> str:
    """
    Strip markdown FORMATTING syntax while preserving ALL content characters,
    including underscores that are part of identifiers like BASF_SC_PELICAN_PI_QA.

    Rules:
      ✅ Remove image syntax      ![alt](url)
      ✅ Unwrap link text         [text](url)  →  text
      ✅ Remove heading markers   ### Title    →  Title
      ✅ Remove bold markers      **text**     →  text  (asterisk bold)
      ✅ Remove bold markers      __text__     →  text  (only when space-bounded)
      ✅ Remove italic markers    *text*       →  text  (asterisk italic)
      ✅ Remove italic markers    _text_       →  text  (ONLY when space/boundary bounded)
      ✅ Remove inline code       `code`
      ✅ Collapse excess newlines
      ❌ NEVER remove _ inside identifiers like BASF_SC_PELICAN_PI_QA
    """
    # 1. Strip images
    text = re.sub(r"!\[.*?\]\(.*?\)", "", text)

    # 2. Unwrap hyperlinks — keep display text, drop URL
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)

    # 3. Remove heading markers (# ## ### etc.)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)

    # 4. Remove bold: **text** and __text__ (double markers)
    #    Safe: double markers are unambiguous
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"__(.+?)__",     r"\1", text)

    # 5. Remove italic asterisk: *text*
    #    Only when * is NOT part of ** (already handled above)
    #    Use negative lookahead/lookbehind to avoid matching **
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"\1", text)

    # 6. ★ FIXED: Remove italic underscore: _text_
    #    ONLY when the underscore is at a true markdown boundary:
    #      - preceded by whitespace, start-of-line, or punctuation (not a word char)
    #      - followed by whitespace, end-of-line, or punctuation (not a word char)
    #    This PRESERVES: BASF_SC_PELICAN, RG_pelican_qa, AP_Cloud_Platform
    #    This REMOVES:   _italic phrase_ when used as markdown emphasis
    text = re.sub(r"(?<!\w)_(?!\s)(.+?)(?<!\s)_(?!\w)", r"\1", text)

    # 7. Remove inline code backticks (single and triple)
    text = re.sub(r"```[\s\S]*?```", "", text)   # fenced code blocks
    text = re.sub(r"`([^`]+)`",      r"\1", text) # inline code — keep content

    # 8. Collapse 3+ consecutive blank lines to 2
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()

def extract_hyperlinks(markdown_text: str) -> str:
    """
    Extract all hyperlinks from raw markdown BEFORE formatting is stripped.

    Captures:
      - Markdown links:  [Display Text](https://...)   (images excluded)
      - Bare HTTP/S URLs not already inside a Markdown link

    Returns a JSON string: [{"text": "...", "url": "..."}, ...]
    Capped at 25 links per page to avoid index bloat.
    """
    links: list = []
    seen_urls: set = set()

    # 1. Markdown hyperlinks — [text](url) — skip images (preceded by !)
    md_re = re.compile(r'(?<!!)\[([^\]\n]{1,200})\]\((https?://[^\)\n]{4,500})\)')
    for m in md_re.finditer(markdown_text):
        text = m.group(1).strip()
        url  = m.group(2).strip()
        if url not in seen_urls:
            links.append({"text": text, "url": url})
            seen_urls.add(url)

    # 2. Bare URLs not yet captured
    bare_re = re.compile(r'(?<!\()(https?://[^\s\)\]<>"\']{10,500})')
    for m in bare_re.finditer(markdown_text):
        url = m.group(1).rstrip('.,;:)\'"')
        if url not in seen_urls:
            try:
                path_parts = urllib.parse.urlparse(url).path.strip('/').split('/')
                label = next(
                    (urllib.parse.unquote(p).replace('-', ' ').replace('_', ' ')
                     for p in reversed(path_parts) if p), ""
                )[:100]
            except Exception:
                label = ""
            links.append({"text": label or url[:100], "url": url})
            seen_urls.add(url)

    return json.dumps(links[:25])


def chunk_text(text: str) -> list:
    paragraphs = text.split("\n\n")
    chunks, current = [], ""
    for para in paragraphs:
        if len(current) + len(para) < CHUNK_SIZE:
            current += "\n\n" + para
        else:
            if current.strip():
                chunks.append(current.strip())
            current = para[-CHUNK_OVERLAP:] + "\n\n" + para
    if current.strip():
        chunks.append(current.strip())
    return chunks if chunks else [text[:CHUNK_SIZE]]

def get_embeddings_batch(texts: list) -> list:
    max_retries = 6
    for attempt in range(max_retries):
        try:
            safe_texts  = [t[:8000] for t in texts]
            resp        = openai_client.embeddings.create(
                model=EMBEDDING_DEPLOYMENT, input=safe_texts)
            sorted_data = sorted(resp.data, key=lambda x: x.index)
            return [item.embedding for item in sorted_data]
        except RateLimitError:
            wait = (2 ** attempt) * 10
            logger.warning(f"Rate limit (attempt {attempt+1}/{max_retries}). Waiting {wait}s…")
            time.sleep(wait)
        except (APIConnectionError, APITimeoutError):
            wait = (2 ** attempt) * 5
            logger.warning(f"Connection error (attempt {attempt+1}/{max_retries}). Waiting {wait}s…")
            time.sleep(wait)
        except Exception as e:
            logger.error(f"Embedding error: {type(e).__name__}: {e}")
            if attempt == max_retries - 1:
                return [[0.0] * 1536] * len(texts)
            time.sleep(5)
    return [[0.0] * 1536] * len(texts)

def upload_to_search(docs: list):
    for attempt in range(3):
        try:
            search_client.upload_documents(docs)
            return
        except Exception as e:
            logger.warning(f"Search upload attempt {attempt+1} failed: {e}")
            time.sleep(2 ** attempt)
    logger.error(f"Failed to upload {len(docs)} docs after 3 attempts")


def get_wiki_configs() -> list:
    """
    Build the list of wiki configurations from environment variables.

    Primary wiki always uses ADO_ORG_URL / ADO_PROJECT / ADO_WIKI_ID / ADO_PAT.
    Additional wikis are configured via numbered env-var blocks:
        ADO_WIKI_2_ORG_URL, ADO_WIKI_2_PROJECT, ADO_WIKI_2_WIKI_ID
        ADO_WIKI_2_PAT           (optional — falls back to primary ADO_PAT)
        ADO_WIKI_2_SOURCE_LABEL  (optional — defaults to "Wiki 2")
    Supports up to ADO_WIKI_5_* blocks.

    Example — adding the AWS wiki:
        ADO_WIKI_2_ORG_URL=https://dev.azure.com/BasfAWS
        ADO_WIKI_2_PROJECT=aws-cloud-platform
        ADO_WIKI_2_WIKI_ID=aws-cloud-platform.wiki
        ADO_WIKI_2_SOURCE_LABEL=AWS Wiki
    """
    primary_label = os.getenv("ADO_WIKI_SOURCE_LABEL", "Azure Wiki").strip()
    configs = [{
        "org_url":      ADO_ORG_URL,
        "project":      ADO_PROJECT,
        "wiki_id":      ADO_WIKI_ID,
        "pat":          ADO_PAT,
        "source_label": primary_label,
        "prefix":       "w1",
    }]
    for n in range(2, 6):
        org = os.getenv(f"ADO_WIKI_{n}_ORG_URL", "").strip().rstrip("/")
        if not org:
            continue
        proj = os.getenv(f"ADO_WIKI_{n}_PROJECT", "").strip("/")
        wid  = os.getenv(f"ADO_WIKI_{n}_WIKI_ID",  "").strip()
        pat  = os.getenv(f"ADO_WIKI_{n}_PAT",       ADO_PAT).strip()
        lbl  = os.getenv(f"ADO_WIKI_{n}_SOURCE_LABEL", f"Wiki {n}").strip()
        if proj and wid:
            configs.append({
                "org_url":      org,
                "project":      proj,
                "wiki_id":      wid,
                "pat":          pat,
                "source_label": lbl,
                "prefix":       f"w{n}",
            })
    logger.info(f"Wiki configs loaded: {[c['source_label'] for c in configs]}")
    return configs

# ── Main ingestion ────────────────────────────────────────────

def ingest():
    """
    Main ingestion entry point.

    1. Creates / updates the Azure AI Search index (adds hyperlinks + wikiSource fields).
    2. Discovers all configured wikis (primary + optional ADO_WIKI_2_* … ADO_WIKI_5_*).
    3. For each wiki: fetches pages, extracts hyperlinks from raw markdown, cleans &
       chunks content, embeds with Azure OpenAI, uploads to Azure AI Search.
    4. Tags every document with wikiSource so cross-wiki queries work at query time.
    """
    create_search_index()
    wiki_configs    = get_wiki_configs()

    all_docs        = []
    total_chunks    = 0
    total_pages     = 0
    skipped         = 0
    pending_records = []
    global_page_idx = 0   # unique id counter across all wikis

    for wiki_cfg in wiki_configs:
        source_label = wiki_cfg["source_label"]
        prefix       = wiki_cfg["prefix"]

        logger.info("=" * 60)
        logger.info(f"Ingesting: {source_label}  (wiki_id={wiki_cfg['wiki_id']})")
        logger.info("=" * 60)

        try:
            pages = get_wiki_pages(wiki_cfg)
        except Exception as exc:
            logger.error(f"❌ Failed to fetch pages for {source_label}: {exc}. Skipping.")
            continue

        for page_idx, page in enumerate(pages):
            path     = page.get("path", "")
            title    = path.split("/")[-1].replace("-", " ") or "Home"
            page_url = build_page_url(path, wiki_cfg)

            logger.info(f"[{source_label}][{page_idx+1}/{len(pages)}] {path}")

            raw = get_page_content(path, wiki_cfg)
            if not raw:
                skipped += 1
                continue

            # ── Extract hyperlinks BEFORE cleaning (preserves all URLs) ──
            hyperlinks_json = extract_hyperlinks(raw)

            clean  = clean_markdown(raw)
            chunks = chunk_text(clean)
            total_pages += 1

            for i, chunk in enumerate(chunks):
                pending_records.append({
                    "id":           f"{prefix}-page-{global_page_idx}-chunk-{i}",
                    "title":        title,
                    "content":      chunk,
                    "embed_text":   f"{title}\n{chunk}",
                    "wikiPath":     path,
                    "pageUrl":      page_url,
                    "chunkIndex":   i,
                    "hyperlinks":   hyperlinks_json,
                    "wikiSource":   source_label,
                })

            global_page_idx += 1

            while len(pending_records) >= EMBED_BATCH_SIZE:
                batch           = pending_records[:EMBED_BATCH_SIZE]
                pending_records = pending_records[EMBED_BATCH_SIZE:]
                embeddings      = get_embeddings_batch([r["embed_text"] for r in batch])
                for rec, emb in zip(batch, embeddings):
                    all_docs.append({
                        "id":            rec["id"],
                        "title":         rec["title"],
                        "content":       rec["content"],
                        "wikiPath":      rec["wikiPath"],
                        "pageUrl":       rec["pageUrl"],
                        "chunkIndex":    rec["chunkIndex"],
                        "hyperlinks":    rec["hyperlinks"],
                        "wikiSource":    rec["wikiSource"],
                        "contentVector": emb,
                    })
                    total_chunks += 1
                if len(all_docs) >= SEARCH_BATCH_SIZE:
                    upload_to_search(all_docs)
                    logger.info(f"  ✅ Uploaded {len(all_docs)} docs (total: {total_chunks})")
                    all_docs = []
                time.sleep(DELAY_BETWEEN_BATCHES)
            time.sleep(DELAY_BETWEEN_PAGES)

    # ── Flush remaining records ────────────────────────────────────────────
    while pending_records:
        batch           = pending_records[:EMBED_BATCH_SIZE]
        pending_records = pending_records[EMBED_BATCH_SIZE:]
        embeddings      = get_embeddings_batch([r["embed_text"] for r in batch])
        for rec, emb in zip(batch, embeddings):
            all_docs.append({
                "id":            rec["id"],
                "title":         rec["title"],
                "content":       rec["content"],
                "wikiPath":      rec["wikiPath"],
                "pageUrl":       rec["pageUrl"],
                "chunkIndex":    rec["chunkIndex"],
                "hyperlinks":    rec["hyperlinks"],
                "wikiSource":    rec["wikiSource"],
                "contentVector": emb,
            })
            total_chunks += 1
        time.sleep(DELAY_BETWEEN_BATCHES)

    if all_docs:
        upload_to_search(all_docs)
        logger.info(f"Uploaded final {len(all_docs)} docs")

    logger.info("=" * 60)
    logger.info(f"✅ Ingestion complete!")
    logger.info(f"   Wikis processed : {len(wiki_configs)}")
    logger.info(f"   Pages processed : {total_pages}")
    logger.info(f"   Pages skipped   : {skipped}")
    logger.info(f"   Chunks indexed  : {total_chunks}")
    logger.info("=" * 60)

if __name__ == "__main__":
    ingest()